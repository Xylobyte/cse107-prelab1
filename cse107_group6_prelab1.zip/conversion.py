meters = float(input("please take a measurement in meters"))
feet = meters*3.281
yards = meters*1.094
miles = meters*0.0006214
print("the measurement in feet is\n"+str(feet))
print("the measurement in yards is\n"+str(yards))
print("the measurement in miles is\n"+str(miles))
