radius = float(input ("Please enter the radius of the circle:"))
area = 3.14*(pow(radius,2))
circ = 2*3.14*radius
print("The area of the circle is " + str(area))
print("The circ of the circle is " + str(circ))